﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Activity1_2.Controllers
{
    public class TestController : Controller
    {
        // GET: Test
        public ActionResult Index()
        {
            return View();
        }
        
        //GET: /Test/TestView
        public ActionResult TestView()
        {
            return View();
        }

        //GET: /Test/ErrorMessage
        public ActionResult ErrorMessage()
        {
            return View();
        }

        public String PrintMessage()
        {
            return "<h1>Welcome</h1> <p>This is the first page in your MVC app</p>";
        }

        public String Play()
        {
            return "<b>Hello World as a string from Play</b>";
        }

        public String Welcome(string name, int numTimes = 1)
        {
            return HttpUtility.HtmlEncode("Hello " + name + ", NumTimes is: " + numTimes); 
        }

        public String Welcome2(string name, int ID = 1)
        {
            return HttpUtility.HtmlEncode("Hello " + name + ", ID: " + ID);
        }
    }
}