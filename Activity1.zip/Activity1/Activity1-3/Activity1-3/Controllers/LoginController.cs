﻿using Activity1_3.Models;
using Activity1_3.Services.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Activity1_3.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View("Login");
        }

        [HttpPost]
        public ActionResult Login(UserModel user)
        {
            //return "Here " + model.Username + " and " + model.Password;
            SecurityService ss = new SecurityService();
            Boolean success = ss.Authenticate(user); 

            if (success)
            {
                return View("LoginSuccess", user); 
            }
            else
            {
                return View("LoginFail"); 
            }
        }
    }
}